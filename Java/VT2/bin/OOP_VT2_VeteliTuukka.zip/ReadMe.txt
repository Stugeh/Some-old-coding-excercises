1. työmäärä: 10-17h

2. helppoa:
	Perusjutut. 
   
   vaikeaa:
     en meinannut millään saada tulostus metodeja toimimaan oikein. Mielin määrin nullPointerException virheitä.

3.    Pikkuhiljaa alan hahmottamaan paremmin säännöt ja
       miten yhteydet metodien luokkien ja muutujien välillä toimivat
	    